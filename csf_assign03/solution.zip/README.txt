Contributions:

MS1: 
    Jayden: Makefile, main
    Nicolas: Main error checking