#include <iostream>
#include <string>
#include "Cache.h"
#include "Set.h"
#include "Slot.h"
using namespace std;

//implement Cache.h functions here